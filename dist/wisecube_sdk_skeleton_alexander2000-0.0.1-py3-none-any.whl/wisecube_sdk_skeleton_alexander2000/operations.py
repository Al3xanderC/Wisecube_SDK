def suma(a, b):
    return a + b


def scadere(a, b):
    return a - b


def produs(a, b):
    return a * b


def imp(a, b):
    if b == 0:
        print("Valoarea lui b trebuie sa fie diferita de 0")
    else:
        return a / b
